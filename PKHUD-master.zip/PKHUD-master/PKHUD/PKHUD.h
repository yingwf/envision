//
//  PKHUD.h
//  PKHUD
//
//  Created by Philip Kluz on 6/17/14.
//  Copyright (c) 2016 NSExceptional. All rights reserved.
//  Licensed under the MIT license.
//

@import UIKit;

//! Project version number for PKHUD.
FOUNDATION_EXPORT double PKHUDVersionNumber;

//! Project version string for PKHUD.
FOUNDATION_EXPORT const unsigned char PKHUDVersionString[];
